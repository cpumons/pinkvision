import cv2

cam = cv2.VideoCapture(0, cv2.CAP_V4L)
print(cam)

img_counter = 0
ret, frame = cam.read()
print(frame)
cv2.imwrite('./test.jpg', frame)
img_counter += 1

cam.release()

